package TaskManagementSystem;

import java.util.ArrayList;
import java.util.Scanner;

public class TaskManagementSystem {

    // Inner class to represent a Task
    static class Task {
        private String description;

        public Task(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        @Override
        public String toString() {
            return description;
        }
    }

    // ArrayList to hold the tasks
    private static ArrayList<Task> taskList = new ArrayList<>();

    // Method to add a task
    public static void addTask(String description) {
        taskList.add(new Task(description));
        System.out.println("Task added successfully!");
    }

    // Method to update a task
    public static void updateTask(int index, String newDescription) {
        if (index >= 0 && index < taskList.size()) {
            Task task = taskList.get(index);
            task.setDescription(newDescription);
            System.out.println("Task updated successfully!");
        } else {
            System.out.println("Invalid task index!");
        }
    }

    // Method to remove a task
    public static void removeTask(int index) {
        if (index >= 0 && index < taskList.size()) {
            taskList.remove(index);
            System.out.println("Task removed successfully!");
        } else {
            System.out.println("Invalid task index!");
        }
    }

    // Method to display all tasks
    public static void displayTasks() {
        if (taskList.isEmpty()) {
            System.out.println("No tasks available.");
        } else {
            for (int i = 0; i < taskList.size(); i++) {
                System.out.println((i + 1) + ". " + taskList.get(i));
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\nTask Management System:");
            System.out.println("1. Add Task");
            System.out.println("2. Update Task");
            System.out.println("3. Remove Task");
            System.out.println("4. Display All Tasks");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline

            switch (choice) {
                case 1:
                    System.out.print("Enter task description: ");
                    String description = scanner.nextLine();
                    addTask(description);
                    break;
                case 2:
                    System.out.print("Enter task number to update: ");
                    int updateIndex = scanner.nextInt() - 1;
                    scanner.nextLine(); // consume the newline
                    System.out.print("Enter new task description: ");
                    String newDescription = scanner.nextLine();
                    updateTask(updateIndex, newDescription);
                    break;
                case 3:
                    System.out.print("Enter task number to remove: ");
                    int removeIndex = scanner.nextInt() - 1;
                    removeTask(removeIndex);
                    break;
                case 4:
                    displayTasks();
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }

        scanner.close();
    }
}
